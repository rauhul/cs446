Main latex file to compile: HW11.tex
Solution file to fill in: HW11_StudentSolution.tex
Final result to submit: HW11.pdf 