main latex file to compile: HW8.tex
solution file to fill in: GMMkMeans_StudentSolution.tex
final result to submit: HW8.pdf
