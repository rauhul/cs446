main latex file to compile: HW12.tex
solution file to fill in: QLearn_StudentSolution.tex
final result to submit: HW12.pdf